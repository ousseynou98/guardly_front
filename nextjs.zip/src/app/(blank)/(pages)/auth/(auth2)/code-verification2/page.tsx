// project-imports
import CodeVerificationPage from 'views/auth/auth2/CodeVerification';

// ================================|| CODE VERIFICATION ||================================ //

export default function CodeVerification() {
  return <CodeVerificationPage />;
}

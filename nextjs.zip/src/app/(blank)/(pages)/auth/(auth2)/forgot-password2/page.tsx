// project-imports
import ForgotPasswordPage from 'views/auth/auth2/ForgotPassword';

// ================================|| FORGOT PASSWORD ||================================ //

export default function ForgotPassword() {
  return <ForgotPasswordPage />;
}

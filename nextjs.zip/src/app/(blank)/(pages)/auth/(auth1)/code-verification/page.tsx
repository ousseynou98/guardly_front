// project-imports
import CodeVerificationPage from 'views/auth/auth1/CodeVerification';

// ================================|| CODE VERIFICATION ||================================ //

export default function CodeVerification() {
  return <CodeVerificationPage />;
}

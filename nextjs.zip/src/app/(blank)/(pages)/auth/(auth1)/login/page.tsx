// project-imports
import LoginPage from 'views/auth/auth1/Login';

// ================================|| LOGIN ||================================ //

export default function Login() {
  return <LoginPage />;
}

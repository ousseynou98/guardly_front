// project-imports
import UnderConstruction2page from 'views/maintenance/UnderConstruction2';

// ==============================|| UNDER CONSTRUCTION ||============================== //

export default function UnderConstruction() {
  return <UnderConstruction2page />;
}

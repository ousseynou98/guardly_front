// project-imports
import Error404Page from 'views/maintenance/Error404';

// ==============================|| ERROR 404 ||============================== //

export default function Error404() {
  return <Error404Page />;
}

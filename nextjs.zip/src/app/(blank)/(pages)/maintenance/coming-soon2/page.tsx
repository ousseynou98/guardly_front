// project-imports
import ComingSoon2Page from 'views/maintenance/ComingSoon2';

// ==============================|| COMING SOON ||============================== //

export default function ComingSoon() {
  return <ComingSoon2Page />;
}

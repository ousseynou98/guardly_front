// project-imports
import WidgetChart from 'views/widget/WidgetChart';

// ==============================|| WIDGET - CHARTS ||============================== //

export default function Chart() {
  return <WidgetChart />;
}

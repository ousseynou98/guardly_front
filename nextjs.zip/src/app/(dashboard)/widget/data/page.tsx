// project-imports
import WidgetData from 'views/widget/WidgetData';

// ===========================|| WIDGET - DATA ||=========================== //

export default function Data() {
  return <WidgetData />;
}

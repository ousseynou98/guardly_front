// project-imports
import Apexcharts from 'views/charts/Apexchart';

// ==============================|| APEX CHARTS ||============================== //

export default function Apexchart() {
  return <Apexcharts />;
}

// project-imports
import InvoiceDashboard from 'views/apps/InvoiceDashboard';

// ==============================|| INVOICE - DASHBOARD ||============================== //

export default function Dashboard() {
  return <InvoiceDashboard />;
}

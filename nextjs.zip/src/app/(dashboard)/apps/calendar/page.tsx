// project-imports
import Calendar from 'views/apps/Calendar';

// ==============================|| CALENDAR - MAIN ||============================== //

export default function CalendarPage() {
  return <Calendar />;
}

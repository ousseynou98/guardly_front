// project-imports
import CustomerList from 'views/apps/CustomerList';

// ==============================|| CUSTOMER - LIST ||============================== //

export default function CustomerListPage() {
  return <CustomerList />;
}

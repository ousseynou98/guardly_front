// project-imports
import Products from 'views/apps/Products';

// ==============================|| ECOMMERCE - PRODUCTS ||============================== //

export default function ProductsPage() {
  return <Products />;
}

// project-imports
import ProductList from 'views/apps/ProductList';

// ==============================|| ECOMMERCE - PRODUCT LIST ||============================== //

export default function ProductListPage() {
  return <ProductList />;
}

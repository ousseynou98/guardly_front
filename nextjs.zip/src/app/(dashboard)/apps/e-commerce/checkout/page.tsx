// project-imports
import Checkout from 'views/apps/Checkout';

// ==============================|| ECOMMERCE - CHECKOUT ||============================== //

export default function CheckoutPage() {
  return <Checkout />;
}

// project-imports
import DashboardAnalytics from 'views/dashboard/DashboardAnalytics';

// ==============================|| DASHBOARD - ANALYTICS ||============================== //

export default function Analytics() {
  return <DashboardAnalytics />;
}

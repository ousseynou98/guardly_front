// project-imports
import Pricing2Page from 'views/price/Pricing2';

// ==============================|| PRICING ||============================== //

export default function Pricing() {
  return <Pricing2Page />;
}

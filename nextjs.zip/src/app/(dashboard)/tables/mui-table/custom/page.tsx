// project-imports
import TableCustomized from 'views/forms-tables/tables/mui-table/TableCustomized';

// ==============================|| MUI TABLE - CUSTOMIZED ||============================== //

export default function CustomizedTables() {
  return <TableCustomized />;
}

// project-imports
import TableDense from 'views/forms-tables/tables/mui-table/TableDense';

// ==============================|| MUI TABLE - DENSE ||============================== //

export default function DenseTable() {
  return <TableDense />;
}

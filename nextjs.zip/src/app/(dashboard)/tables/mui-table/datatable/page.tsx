// project-imports
import TableData from 'views/forms-tables/tables/mui-table/TableData';

// ==============================|| TABLE - DATA TABLE ||============================== //

export default function EnhancedTable() {
  return <TableData />;
}

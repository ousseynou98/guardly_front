// project-imports
import TableBasic from 'views/forms-tables/tables/mui-table/TableBasic';

// ==============================|| MUI TABLE - BASIC ||============================== //

export default function Basic() {
  return <TableBasic />;
}

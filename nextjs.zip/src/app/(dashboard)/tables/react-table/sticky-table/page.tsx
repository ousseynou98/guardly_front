// project-imports
import StickyTables from 'views/forms-tables/tables/react-table/StickyTables';

// ==============================|| REACT TABLE - STICKY ||============================== //

export default function Sticky() {
  return <StickyTables />;
}

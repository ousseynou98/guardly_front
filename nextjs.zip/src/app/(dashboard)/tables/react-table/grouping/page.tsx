// project-imports
import GroupingTables from 'views/forms-tables/tables/react-table/GroupingTables';

// ==============================|| REACT TABLE - GROUPING ||============================== //

export default function Grouping() {
  return <GroupingTables />;
}

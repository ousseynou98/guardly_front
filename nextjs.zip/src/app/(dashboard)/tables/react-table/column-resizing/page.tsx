// project-imports
import ColumnResizingTable from 'views/forms-tables/tables/react-table/ColumnResizingTable';

// ==============================|| REACT TABLE - COLUMN RESIZING ||============================== //

export default function ColumnResizing() {
  return <ColumnResizingTable />;
}

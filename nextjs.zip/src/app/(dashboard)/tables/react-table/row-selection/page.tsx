// project-imports
import RowSelectionTable from 'views/forms-tables/tables/react-table/RowSelectionTable';

// ==============================|| REACT TABLE - ROW SELECTION ||============================== //

export default function RowSelection() {
  return <RowSelectionTable />;
}

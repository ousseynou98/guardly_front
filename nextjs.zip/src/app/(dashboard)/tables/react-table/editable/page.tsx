// project-imports
import EditableTable from 'views/forms-tables/tables/react-table/EditableTable';

// ==============================|| REACT TABLE - EDITABLE ||============================== //

export default function Editable() {
  return <EditableTable />;
}

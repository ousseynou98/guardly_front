// project-imports
import DenseTable from 'views/forms-tables/tables/react-table/DenseTable';

// ==============================|| REACT TABLE - EDITABLE ||============================== //

export default function Dense() {
  return <DenseTable />;
}

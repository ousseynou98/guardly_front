// project-imports
import BasicTables from 'views/forms-tables/tables/react-table/BasicTable';

// ==============================|| REACT TABLE - BASIC ||============================== //

export default function Basic() {
  return <BasicTables />;
}

// project-imports
import PaginationTable from 'views/forms-tables/tables/react-table/PaginationTable';

// ==============================|| REACT TABLE - PAGINATION ||============================== //

export default function Pagination() {
  return <PaginationTable />;
}

// project-imports
import FormsValidationPage from 'views/forms-tables/forms/FormsValidation';

// ==============================|| FORMS VALIDATION - FORMIK ||============================== //

export default function FormsValidation() {
  return <FormsValidationPage />;
}

// project-imports
import MaskPage from 'views/forms-tables/forms/plugins/MaskPage';

// ==============================|| PLUGIN - MASK INPUT ||============================== //

export default function Mask() {
  return <MaskPage />;
}

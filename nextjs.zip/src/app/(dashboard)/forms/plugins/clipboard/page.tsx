// project-imports
import ClipboardPage from 'views/forms-tables/forms/plugins/ClipboardPage';

// ==============================|| PLUGIN - CLIPBOARD ||============================== //

export default function Clipboard() {
  return <ClipboardPage />;
}

// project-imports
import DropzonePage from 'views/forms-tables/forms/plugins/DropzonePage';

// ==============================|| PLUGIN - DROPZONE ||============================== //

export default function Dropzone() {
  return <DropzonePage />;
}

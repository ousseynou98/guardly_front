// project-imports
import Maps from 'views/map/map';

// ==============================|| MAP ||============================== //

export default function Map() {
  return <Maps />;
}

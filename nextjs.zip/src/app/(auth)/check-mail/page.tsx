// project-imports
import CheckMail from 'views/authentication/CheckMail';

// ================================|| CHECK MAIL ||================================ //

export default function CheckMailPage() {
  return <CheckMail />;
}

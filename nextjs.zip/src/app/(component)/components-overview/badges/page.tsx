// project-imports
import ComponentBadge from 'views/components-overview/ComponentBadge';

// ==============================|| COMPONENTS - BADGES ||============================== //

export default function ComponentBadgePage() {
  return <ComponentBadge />;
}

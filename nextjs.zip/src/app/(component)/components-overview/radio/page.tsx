// project-imports
import ComponentRadio from 'views/components-overview/ComponentRadio';

// ==============================|| COMPONENTS - RADIO ||============================== //

export default function ComponentRadioPage() {
  return <ComponentRadio />;
}

// project-imports
import ComponentAvatar from 'views/components-overview/ComponentAvatar';

// ==============================|| COMPONENTS - AVATAR ||============================== //

export default function ComponentAvatarPage() {
  return <ComponentAvatar />;
}

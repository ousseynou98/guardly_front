// project-imports
import ComponentModal from 'views/components-overview/ComponentModal';

// ==============================|| COMPONENTS - MODAL ||============================== //

export default function ComponentModalPage() {
  return <ComponentModal />;
}

// project-imports
import ComponentDialogs from 'views/components-overview/ComponentDialogs';

// ==============================|| COMPONENTS - DIALOGS ||============================== //

export default function DialogsPage() {
  return <ComponentDialogs />;
}

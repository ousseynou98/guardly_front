// project-imports
import ComponentPagination from 'views/components-overview/ComponentPagination';

// ==============================|| COMPONENTS - PAGINATION ||============================== //

export default function ComponentPaginationPage() {
  return <ComponentPagination />;
}

// project-imports
import ComponentTypography from 'views/components-overview/ComponentTypography';

// ==============================|| COMPONENTS - TYPOGRAPHY ||============================== //

export default function ComponentTypographyPage() {
  return <ComponentTypography />;
}

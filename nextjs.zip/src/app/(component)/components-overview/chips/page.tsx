// project-imports
import ComponentChip from 'views/components-overview/ComponentChip';

// ==============================|| COMPONENTS - CHIPS ||============================== //

export default function ComponentChipPage() {
  return <ComponentChip />;
}

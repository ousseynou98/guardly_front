// project-imports
import ComponentColor from 'views/components-overview/ComponentColor';

// ===============================|| COMPONENTS - COLOR ||=============================== //

export default function ComponentColorPage() {
  return <ComponentColor />;
}

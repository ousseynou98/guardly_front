// project-imports
import ComponentTooltip from 'views/components-overview/ComponentTooltip';

// ==============================|| COMPONENTS - TOOLTIP ||============================== //

export default function ComponentTooltipPage() {
  return <ComponentTooltip />;
}

// project-imports
import ComponentTabs from 'views/components-overview/ComponentTabs';

// ==============================|| COMPONENTS - TABS ||============================== //

export default function ComponentTabsPage() {
  return <ComponentTabs />;
}

// project-imports
import ComponentList from 'views/components-overview/ComponentList';

// ==============================|| COMPONENTS - LIST ||============================== //

export default function ComponentListPage() {
  return <ComponentList />;
}

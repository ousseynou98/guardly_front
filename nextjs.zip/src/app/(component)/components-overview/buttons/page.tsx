// project-imports
import ComponentButtons from 'views/components-overview/ComponentButtons';

// ==============================|| COMPOENETS - BUTTON ||============================== //

export default function ButtonsPage() {
  return <ComponentButtons />;
}

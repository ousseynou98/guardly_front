// project-imports
import ComponentTextField from 'views/components-overview/ComponentTextField';

// ==============================|| COMPONENTS - TEXT FEILD ||============================== //

export default function ComponentTextFieldPage() {
  return <ComponentTextField />;
}

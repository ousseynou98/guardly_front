// project-imports
import ComponentAlert from 'views/components-overview/ComponentAlert';

// ==============================|| COMPONENTS - ALERTS ||============================== //

export default function ComponentAlertPage() {
  return <ComponentAlert />;
}

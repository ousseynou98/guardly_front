// project-imports
import ContactUSPage from 'views/contact-us/ContactUS';

// ==============================|| CONTACT US - MAIN ||============================== //

export default function contactUS() {
  return <ContactUSPage />;
}
